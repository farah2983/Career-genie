export const NavbarMenu = [
    {
        id: 1,
        title: 'Home',
        link:"/home-page"
    },
    {
        id: 2,
        title: 'Features',
        link:"#"
    },
    {
        id: 3,
        title: 'How it works',
        link:"#"
    },
    {
        id: 4,
        title: 'Why us',
        link:"#"
    }, 

    
]