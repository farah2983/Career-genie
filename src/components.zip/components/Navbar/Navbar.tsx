import { NavbarMenu } from "../mockData/data"
const Navbar = () => {
  return (
    <>
      <nav>
        <div className="container flex justify-between items-center py-8">
          {/* logo section */}
          <div className="mb-6 text-left shrink-0">
            <img src="/logo.svg" alt="logo" className="w-48 sm:w-60 mx-auto mb-2" />
          </div>
          {/* menu section */}
          <div>
            <ul className="flex items-center gap-4 text-gray-600">
              {
                NavbarMenu.map((item) => {
                  return (
                    <li key={item.id}>
                      <a href={item.link} className="inline-block py-1 px-3 hover:text-gray-700">
                        {item.title}
                      </a>
                    </li>
                  )
                })
              }
            </ul>
          </div>
          {/* account section */}
          <div>
            <button
              type="button"
              className={`flex-1 py-2 z-10 transition-colors ${ "text-black font-semibold"}`}
              onClick={() => {  }}
            >
              Get started
            </button>
          </div>
        </div>
      </nav>
    </>
  )
}

export default Navbar